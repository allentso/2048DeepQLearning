import pygame
import random
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import matplotlib.pyplot as plt
import matplotlib
import sys
from collections import namedtuple, deque
import logging
import time  # 添加用于减慢训练速度
import os

# 确保 'model' 目录存在
os.makedirs("model", exist_ok=True)
# 设置PyTorch设备
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 游戏常量
tile_size = 85
padding = 12
move_speed = 20
alpha_speed = 20
screen_width, screen_height = 800, 600
texture_path = 'assets/tiles/'  # 确保此目录存在并包含瓦片图像

# 初始化pygame
pygame.init()
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("2048 Q-Learning")
my_font = pygame.font.SysFont('Arial', 30)

# Tile类
class Tile:
    def __init__(self, value, col, row, offset_x, offset_y, alpha=255):
        self.value = value
        self.texture = pygame.image.load(texture_path + str(value) + '.png').convert()
        self.joinable = True
        self.pos_x = padding * (col + 1) + col * tile_size + offset_x
        self.pos_y = padding * (row + 1) + row * tile_size + offset_y
        self.target_x = self.pos_x
        self.target_y = self.pos_y
        self.offset_x = offset_x
        self.offset_y = offset_y
        self.alpha = alpha
        self.texture.set_alpha(self.alpha)

    def update(self, value):
        self.value = value
        self.texture = pygame.image.load(texture_path + str(value) + '.png').convert()

    def animate(self):
        if self.pos_x != self.target_x:
            self.pos_x += min(move_speed * ((self.target_x - self.pos_x) / abs(self.target_x - self.pos_x)), self.target_x - self.pos_x, key=abs)
        if self.pos_y != self.target_y:
            self.pos_y += min(move_speed * ((self.target_y - self.pos_y) / abs(self.target_y - self.pos_y)), self.target_y - self.pos_y, key=abs)
        if self.alpha < 255:
            self.alpha += min(alpha_speed, 255 - self.alpha)
            self.texture.set_alpha(self.alpha)

    def move(self, col, row):
        self.target_x = padding * (col + 1) + col * tile_size + self.offset_x
        self.target_y = padding * (row + 1) + row * tile_size + self.offset_y

    def draw(self, screen):
        screen.blit(self.texture, (self.pos_x, self.pos_y))

# Board类
class Board:
    def __init__(self, pos_x, pos_y):
        self.grid = [[None for _ in range(4)] for _ in range(4)]
        self.trash = []
        self.pos_x = pos_x
        self.pos_y = pos_y
        self.texture = pygame.image.load('assets/board.png').convert()
        self.game_over_texture = pygame.image.load('assets/restart.png').convert_alpha()
        self.add_tile()
        self.add_tile()

    def add_tile(self):
        empty_positions = [(i, j) for i in range(4) for j in range(4) if self.grid[i][j] is None]
        if empty_positions:
            i, j = random.choice(empty_positions)
            value = random.choices([2, 4], weights=[0.9, 0.1], k=1)[0]
            self.grid[i][j] = Tile(value, i, j, self.pos_x, self.pos_y, 0)

    def move_tiles(self, direction):
        points = 0
        reward = 0
        for i in range(4):
            for j in range(4):
                if self.grid[i][j] is not None:
                    self.grid[i][j].joinable = True
        action = False
        if direction == 'u':
            for _ in range(3):
                for x in range(4):
                    for y in range(1, 4):
                        if self.grid[x][y] is None:
                            continue
                        if self.grid[x][y-1] is None:
                            self.grid[x][y].move(x, y-1)
                            self.grid[x][y-1] = self.grid[x][y]
                            self.grid[x][y] = None
                            action = True
                        elif self.grid[x][y-1].value == self.grid[x][y].value and self.grid[x][y-1].joinable and self.grid[x][y].joinable:
                            self.grid[x][y-1].update(self.grid[x][y-1].value * 2)
                            points += self.grid[x][y-1].value
                            reward += self.grid[x][y-1].value.bit_length()
                            self.grid[x][y-1].joinable = False
                            self.grid[x][y].move(x, y-1)
                            self.trash.append(self.grid[x][y])
                            self.grid[x][y] = None
                            action = True
        # 其他方向（d, l, r）的逻辑与原代码相同，略去以节省篇幅
        elif direction == 'd':
            for _ in range(3):
                for x in range(4):
                    for y in range(2, -1, -1):
                        if self.grid[x][y] is None:
                            continue
                        if self.grid[x][y+1] is None:
                            self.grid[x][y].move(x, y+1)
                            self.grid[x][y+1] = self.grid[x][y]
                            self.grid[x][y] = None
                            action = True
                        elif self.grid[x][y+1].value == self.grid[x][y].value and self.grid[x][y+1].joinable and self.grid[x][y].joinable:
                            self.grid[x][y+1].update(self.grid[x][y+1].value * 2)
                            points += self.grid[x][y+1].value
                            reward += self.grid[x][y+1].value.bit_length()
                            self.grid[x][y+1].joinable = False
                            self.grid[x][y].move(x, y+1)
                            self.trash.append(self.grid[x][y])
                            self.grid[x][y] = None
                            action = True
        elif direction == 'l':
            for _ in range(3):
                for x in range(1, 4):
                    for y in range(4):
                        if self.grid[x][y] is None:
                            continue
                        if self.grid[x-1][y] is None:
                            self.grid[x][y].move(x-1, y)
                            self.grid[x-1][y] = self.grid[x][y]
                            self.grid[x][y] = None
                            action = True
                        elif self.grid[x-1][y].value == self.grid[x][y].value and self.grid[x-1][y].joinable and self.grid[x][y].joinable:
                            self.grid[x-1][y].update(self.grid[x-1][y].value * 2)
                            points += self.grid[x-1][y].value
                            reward += self.grid[x-1][y].value.bit_length()
                            self.grid[x-1][y].joinable = False
                            self.grid[x][y].move(x-1, y)
                            self.trash.append(self.grid[x][y])
                            self.grid[x][y] = None
                            action = True
        elif direction == 'r':
            for _ in range(3):
                for x in range(2, -1, -1):
                    for y in range(4):
                        if self.grid[x][y] is None:
                            continue
                        if self.grid[x+1][y] is None:
                            self.grid[x][y].move(x+1, y)
                            self.grid[x+1][y] = self.grid[x][y]
                            self.grid[x][y] = None
                            action = True
                        elif self.grid[x+1][y].value == self.grid[x][y].value and self.grid[x+1][y].joinable and self.grid[x][y].joinable:
                            self.grid[x+1][y].update(self.grid[x+1][y].value * 2)
                            points += self.grid[x+1][y].value
                            reward += self.grid[x+1][y].value.bit_length()
                            self.grid[x+1][y].joinable = False
                            self.grid[x][y].move(x+1, y)
                            self.trash.append(self.grid[x][y])
                            self.grid[x][y] = None
                            action = True
        if not action:
            return -1, -1
        else:
            self.add_tile()
        return points, reward

    def is_game_over(self):
        for x in range(4):
            for y in range(4):
                if self.grid[x][y] is None:
                    return False
                if x > 0 and self.grid[x-1][y] and self.grid[x][y].value == self.grid[x-1][y].value:
                    return False
                if x < 3 and self.grid[x+1][y] and self.grid[x][y].value == self.grid[x+1][y].value:
                    return False
                if y > 0 and self.grid[x][y-1] and self.grid[x][y].value == self.grid[x][y-1].value:
                    return False
                if y < 3 and self.grid[x][y+1] and self.grid[x][y].value == self.grid[x][y+1].value:
                    return False
        return True

    def reset_board(self):
        self.grid = [[None for _ in range(4)] for _ in range(4)]
        self.add_tile()
        self.add_tile()

    def draw(self, screen, game_over):
        screen.blit(self.texture, (self.pos_x, self.pos_y))
        for t_tile in self.trash[:]:
            t_tile.draw(screen)
            t_tile.animate()
            if t_tile.pos_x == t_tile.target_x and t_tile.pos_y == t_tile.target_y:
                self.trash.remove(t_tile)
        for x in range(4):
            for y in range(4):
                if self.grid[x][y] is not None:
                    self.grid[x][y].draw(screen)
                    self.grid[x][y].animate()
        if game_over:
            screen.blit(self.game_over_texture, (self.pos_x, self.pos_y))

# DQN模型类
class DQN(nn.Module):
    def __init__(self, n_observations, n_actions):
        super(DQN, self).__init__()
        self.layer1 = nn.Linear(n_observations, 256)
        self.layer2 = nn.Linear(256, 256)
        self.layer3 = nn.Linear(256, 256)
        self.layer4 = nn.Linear(256, n_actions)

    def forward(self, x):
        x = F.relu(self.layer1(x))
        x = F.relu(self.layer2(x))
        x = F.relu(self.layer3(x))
        return self.layer4(x)

# 经验回放类
class ReplayMemory:
    def __init__(self, capacity):
        self.memory = deque([], maxlen=capacity)
        self.Transition = namedtuple('Transition', ('state', 'action', 'next_state', 'reward'))

    def push(self, *args):
        self.memory.append(self.Transition(*args))

    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)

    def __len__(self):
        return len(self.memory)

# Agent类
class Agent:
    def __init__(self, source_path=None, dest_path=None, batch_size=64, gamma=0.99, eps_start=0.95, eps_end=0.05, eps_decay=500, tau=0.005, lr=1e-3, memory_capacity=2000, plotting=True, logs=False):
        self.source_path = source_path
        self.dest_path = dest_path
        self.batch_size = batch_size
        self.gamma = gamma
        self.eps_start = eps_start
        self.eps_end = eps_end
        self.eps_decay = eps_decay
        self.tau = tau
        self.lr = lr
        self.memory_capacity = memory_capacity
        self.plotting = plotting
        self.logs = logs
        self.env = Game()
        if self.logs:
            logging.basicConfig(filename='training.log', level=logging.INFO, format='[%(asctime)s] - %(message)s')
        n_actions = 4  # 上、下、左、右
        state = self.env.reset()
        n_observations = len(state)
        self.policy_net = DQN(n_observations, n_actions).to(device)
        if self.source_path is not None:
            self.policy_net.load_state_dict(torch.load(self.source_path))
        self.target_net = DQN(n_observations, n_actions).to(device)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.optimizer = optim.AdamW(self.policy_net.parameters(), lr=self.lr, amsgrad=True)
        self.memory = ReplayMemory(memory_capacity)
        if self.plotting:
            matplotlib.use("TkAgg")
            plt.ion()
        self.steps_done = 0
        self.episode_scores = []

    def optimize_model(self):
        if len(self.memory) < self.batch_size:
            return
        transitions = self.memory.sample(self.batch_size)
        batch = self.memory.Transition(*zip(*transitions))
        non_final_mask = torch.tensor(tuple(map(lambda s: s is not None, batch.next_state)), device=device, dtype=torch.bool)
        non_final_next_states = torch.cat([s for s in batch.next_state if s is not None])
        state_batch = torch.cat(batch.state)
        action_batch = torch.cat(batch.action)
        reward_batch = torch.cat(batch.reward)
        state_action_values = self.policy_net(state_batch).gather(1, action_batch)
        next_state_values = torch.zeros(self.batch_size, device=device)
        with torch.no_grad():
            next_state_values[non_final_mask] = self.target_net(non_final_next_states).max(1)[0]
        expected_state_action_values = (next_state_values * self.gamma) + reward_batch
        criterion = nn.SmoothL1Loss()
        loss = criterion(state_action_values, expected_state_action_values.unsqueeze(1))
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_value_(self.policy_net.parameters(), 100)
        self.optimizer.step()

    def plot_scores(self, show_result=False):
        plt.figure(1)
        plt.clf()
        durations_t = torch.tensor(self.episode_scores, dtype=torch.float)
        plt.title('Training...' if not show_result else 'Training Result')
        plt.xlabel('Episode')
        plt.ylabel('Score')
        plt.plot(durations_t.numpy())
        if len(durations_t) >= 100:
            means = durations_t.unfold(0, 100, 1).mean(1).view(-1)
            means = torch.cat((torch.zeros(99), means))
            plt.plot(means.numpy(), label='100-episode avg')
            plt.legend()
        plt.pause(0.1)  # 增加暂停时间以确保刷新
        if show_result:
            plt.show(block=True)

    def train(self, num_episodes=100000):
        if self.logs:
            logging.info(f'Start training for {num_episodes} episodes')
        if self.plotting:
            self.plot_scores()

        for i in range(num_episodes):
            state = self.env.reset()
            state = state.to(dtype=torch.float32).unsqueeze(0)
            prev = (None, None)

            while True:
                self.env.update()
                time.sleep(0.01)  # 减慢速度以观察游戏窗口，可根据需要调整或移除
                inv = None
                if prev[1] == -15:
                    inv = prev[0]
                action = self.select_action(state, invalid=inv)
                observation, reward, terminated, truncated = self.env.step(action)
                prev = (action, reward)
                reward = torch.tensor([reward], device=device)
                done = terminated or truncated
                if terminated:
                    next_state = None
                else:
                    next_state = observation.clone().detach().to(dtype=torch.float32).unsqueeze(0)
                self.memory.push(state, action, next_state, reward)
                state = next_state
                self.optimize_model()
                target_net_state_dict = self.target_net.state_dict()
                policy_net_state_dict = self.policy_net.state_dict()
                for key in policy_net_state_dict:
                    target_net_state_dict[key] = policy_net_state_dict[key] * self.tau + target_net_state_dict[key]*(1-self.tau)
                self.target_net.load_state_dict(target_net_state_dict)
                if done:
                    current_score = self.env.current_score()
                    self.episode_scores.append(current_score)
                    print(f"Episode {i+1}/{num_episodes} - Score: {current_score}")  # 实时打印每回合分数
                    if self.plotting:
                        self.plot_scores()
                    break

            if (i + 1) % 50 == 0 and self.dest_path is not None:
                torch.save(self.policy_net.state_dict(), self.dest_path)
                if self.logs:
                    avg = sum(self.episode_scores[-50:]) / 50
                    logging.info(f'Episode {i+1}/{num_episodes} - Average score: {avg}')
                print(f"Model saved at episode {i+1}")  # 提示模型保存

        print('Training Complete')
        if self.plotting:
            self.plot_scores(show_result=True)
            plt.ioff()
            plt.show()
        if self.dest_path is not None:
            torch.save(self.policy_net.state_dict(), self.dest_path)
        if self.logs:
            avg = sum(self.episode_scores[-50:]) / 50
            logging.info(f'FINISHED! Episode {num_episodes}/{num_episodes} - Average score: {avg}')

    def select_action(self, state, train=True, invalid=None):
        sample = random.random()
        eps_threshold = self.eps_end + (self.eps_start - self.eps_end) * math.exp(-1. * self.steps_done / self.eps_decay)
        if not train:
            eps_threshold = self.eps_end
        self.steps_done += 1
        if sample > eps_threshold:
            with torch.no_grad():
                values = self.policy_net(state)
                if invalid is not None:
                    fi, se = torch.topk(values, 2).indices.squeeze()
                    return fi.view(1, 1) if fi != invalid else se.view(1, 1)
                else:
                    return values.max(1)[1].view(1, 1)
        else:
            choose = random.randint(0, 3)
            return torch.tensor([[choose]], device=device, dtype=torch.long)

# Game类
class Game:
    def __init__(self, moves_limit=10000, wrong_moves_limit=64):
        self.game_over = False
        self.board = Board(200, 120)
        self.score = Score(screen_width, screen_height)
        self.moves_limit = moves_limit
        self.wrong_moves_limit = wrong_moves_limit
        self.moves = 0
        self.wrong_moves = 0

    def update(self):
        if self.board.is_game_over():
            self.game_over = True
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        screen.fill((255, 255, 255))
        self.board.draw(screen, self.game_over)
        self.score.draw(screen)
        pygame.display.flip()
        # time.sleep(0.05)  # 可选：在此处减慢游戏刷新速度以观察每一步

    def step(self, action):  # 0, 1, 2, 3 -> 上、右、下、左
        points = 0
        reward = 0
        if action == 0:
            points, reward = self.board.move_tiles('u')
        elif action == 1:
            points, reward = self.board.move_tiles('r')
        elif action == 2:
            points, reward = self.board.move_tiles('d')
        elif action == 3:
            points, reward = self.board.move_tiles('l')
        if points == -1:  # 无效移动
            reward = -15
            self.wrong_moves += 1
        else:
            self.score.add_points(points)
            self.wrong_moves = 0
        self.moves += 1
        game_over = self.game_over
        if game_over:
            reward = -10
        truncate = (self.moves > self.moves_limit) or (self.wrong_moves > self.wrong_moves_limit)
        return self.current_state(), reward, game_over, truncate

    def reset(self):
        self.board.reset_board()
        self.game_over = False
        self.score.reset()
        self.moves = 0
        self.wrong_moves = 0
        return self.current_state()

    def current_state(self):
        output = []
        for i in range(4):
            for j in range(4):
                if self.board.grid[i][j] is not None:
                    output.append([1 if self.board.grid[i][j].value.bit_length() == k else 0 for k in range(2, 19)])
                else:
                    output.append([0 for _ in range(17)])
        return torch.tensor(output, dtype=torch.float32).flatten()

    def current_score(self):
        return self.score.value

# Score类
class Score:
    def __init__(self, screen_width, screen_height):
        self.value = 0
        self.screen_width = screen_width
        self.screen_height = screen_height

    def add_points(self, value):
        self.value += value

    def reset(self):
        self.value = 0

    def draw(self, screen):
        text_surface = my_font.render('Score: ' + str(self.value), True, (119, 110, 101))
        screen.blit(text_surface, ((self.screen_width - text_surface.get_width()) // 2, 0))

# 主执行
if __name__ == "__main__":
    agent = Agent(
        dest_path="model/2048_model.pth",
        batch_size=128,
        gamma=0.99,
        eps_start=0.9,
        eps_end=0.05,
        eps_decay=1000,
        tau=0.005,
        lr=1e-4,
        memory_capacity=10000,
        plotting=True,
        logs=True
    )
    agent.train(num_episodes=1000)  # 训练1000回合